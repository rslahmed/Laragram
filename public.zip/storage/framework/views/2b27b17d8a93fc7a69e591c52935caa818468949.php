<?php $__env->startSection('content'); ?>

    <div class="container pt-4">
        <div class="row">
            <div class="col-md-3 offset-1">
                <img style="width: 180px; height: 180px; object-fit: cover" class="rounded-circle" src="<?php echo e(asset($profile->image ?? '/uploads/profile/default.png')); ?>" alt="">
            </div>
            <div class="com-md-6 pt-4">
                <div class="d-flex justify-content-between align-items-center">
                   <h2 class="mr-5"><?php echo e($profile->user->username); ?></h2>
                    <?php if($profile->id == \Illuminate\Support\Facades\Auth::id()): ?>
                    <a class="btn btn-sm btn-secondary" href="/profile/edit" >Edit Profile</a>
                        <?php else: ?>
                        <a class="btn btn-sm btn-secondary" href="<?php echo e(url('/follow/'.$profile->user->id)); ?>" >
                        <?php if(Auth::User()->isFollowing($profile->user->id)): ?>
                            Unfollow
                        <?php else: ?>
                                Follow
                        <?php endif; ?>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="d-flex">
                    <p class="mr-3"><?php echo e(count($posts)); ?> post</p>
                    <p class="mr-3"><?php echo e($followers->count()); ?> follower</p>
                    <p class="mr-3"><?php echo e($profile->user->follows->count()); ?> following</p>
                </div>

                <h6 class="mt-4 font-weight-bold"><?php echo e($profile->user->name); ?></h6>
                <h6 class="mt-1"><?php echo e($profile->bio); ?></h6>
                <?php if($profile->id == \Illuminate\Support\Facades\Auth::id()): ?>
                    <a class="" href="/post/add" >Add Post+</a>
                <?php endif; ?>
            </div>
        </div>

        <hr>

        <div class="row mt-4">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <a href="<?php echo e(url('post/view/'.$post->id)); ?>"><img style="max-height: 250px; object-fit: cover" class="w-100 img-thumbnail" src="<?php echo e(asset($post->image)); ?>" alt=""></a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laragram\resources\views/profile/view-profile.blade.php ENDPATH**/ ?>