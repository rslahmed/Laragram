$( document ).ready(function() {

    // recent user close
    $('#close_recent_user').click(function(){
        $('#recent_user_wrap').hide()
    })

});
